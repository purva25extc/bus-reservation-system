package com.example.busreservation.service;

import com.example.busreservation.model.Booking;
import com.example.busreservation.model.Bus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

@Service
public class BookingService {
    private final BusService busService;
    private final List<Booking> bookings = new CopyOnWriteArrayList<>();

    public BookingService(BusService busService) {
        this.busService = busService;
    }

    public Booking create(Long busId, String name, String email, String phone, List<Integer> seats) {
        Bus bus = busService.get(busId);
        if (bus == null) throw new IllegalArgumentException("Bus not found.");
        if (!busService.bookSeats(busId, seats)) {
            throw new IllegalArgumentException("One or more selected seats are no longer available.");
        }

        String id = "BUS-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        Booking booking = new Booking(
                id, bus.getId(), bus.getName(), bus.getSource(), bus.getDestination(),
                name, email, phone, new ArrayList<>(seats), bus.getPrice() * seats.size()
        );
        bookings.add(booking);
        return booking;
    }

    public List<Booking> all() {
        return new ArrayList<>(bookings);
    }

    public boolean cancel(String id) {
        Booking booking = bookings.stream()
                .filter(b -> b.getBookingId().equalsIgnoreCase(id))
                .findFirst().orElse(null);
        if (booking == null) return false;
        busService.releaseSeats(booking.getBusId(), booking.getSeats());
        return bookings.remove(booking);
    }
}
