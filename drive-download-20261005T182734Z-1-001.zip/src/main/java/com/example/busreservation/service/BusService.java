package com.example.busreservation.service;

import com.example.busreservation.model.Bus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class BusService {
    private final List<Bus> buses = new ArrayList<>();

    public BusService() {
        buses.add(new Bus(1L, "Shivneri Express", "Mumbai", "Pune", "06:30 AM", "09:30 AM", "AC Seater", 40, 450));
        buses.add(new Bus(2L, "Neeta Travels", "Mumbai", "Pune", "08:00 AM", "11:15 AM", "AC Sleeper", 36, 650));
        buses.add(new Bus(3L, "Purple Bus", "Mumbai", "Nashik", "07:15 AM", "11:00 AM", "AC Seater", 40, 520));
        buses.add(new Bus(4L, "MSRTC Express", "Pune", "Mumbai", "05:45 PM", "09:00 PM", "Non-AC Seater", 40, 380));
        buses.add(new Bus(5L, "Volvo Premium", "Mumbai", "Goa", "09:00 PM", "07:00 AM", "AC Sleeper", 32, 1200));
        buses.add(new Bus(6L, "City Connect", "Pune", "Nashik", "10:30 AM", "02:15 PM", "AC Seater", 40, 500));
    }

    public synchronized List<Bus> search(String source, String destination) {
        return buses.stream()
                .filter(b -> source == null || source.isBlank() ||
                        b.getSource().toLowerCase(Locale.ROOT).contains(source.toLowerCase(Locale.ROOT)))
                .filter(b -> destination == null || destination.isBlank() ||
                        b.getDestination().toLowerCase(Locale.ROOT).contains(destination.toLowerCase(Locale.ROOT)))
                .toList();
    }

    public synchronized Bus get(Long id) {
        return buses.stream().filter(b -> b.getId().equals(id)).findFirst().orElse(null);
    }

    public synchronized boolean bookSeats(Long busId, List<Integer> seats) {
        Bus bus = get(busId);
        if (bus == null || seats == null || seats.isEmpty()) return false;
        if (seats.stream().anyMatch(s -> s < 1 || s > bus.getTotalSeats())) return false;
        if (seats.stream().anyMatch(bus.getBookedSeats()::contains)) return false;
        bus.getBookedSeats().addAll(seats);
        return true;
    }

    public synchronized void releaseSeats(Long busId, List<Integer> seats) {
        Bus bus = get(busId);
        if (bus != null && seats != null) bus.getBookedSeats().removeAll(seats);
    }
}
